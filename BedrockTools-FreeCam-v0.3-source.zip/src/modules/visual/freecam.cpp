#include "freecam.hpp"
#include "core/memory/Hooks.hpp"
#include "modules/ModuleRegistry.hpp"
#include <bedrocktools/events/AttackEvent.hpp>
#include <bedrocktools/memory/Signatures.hpp>
#include <bedrocktools/sdk/client/ClientInstance.hpp>
#include <bedrocktools/sdk/render/LevelRendererPlayer.hpp>
#include <bedrocktools/sdk/world/Actor.hpp>
#include <bedrocktools/sdk/Memory.hpp>
#include <bedrocktools/sdk/Offsets.hpp>
#include <pl/ModMenu.hpp>
#include <algorithm>
#include <cmath>
#include <string_view>

static FreeCamModule* g_freecam = nullptr;
static void (*g_renderLevelOriginal)(void*, void*, void*) = nullptr;

static void freecamRenderHook(void* renderer, void* screenContext, void* a3) {
    if (g_freecam && g_freecam->enabled) {
        auto* client = bedrocktools::sdk::ClientInstance::current();
        if (client) {
            auto* player = client->localPlayer();
            if (player) {
                auto* lrp = client->levelRenderer();
                if (lrp) {
                    lrp->cameraPosition() = g_freecam->m_camera;
                }
            }
        }
    }
    if (g_renderLevelOriginal) g_renderLevelOriginal(renderer, screenContext, a3);
}

static void registerHoldButton(const char* id, const char* label, bool* state) {
    pl::modmenu::ButtonBuilder(id, label)
        .behavior(pl::modmenu::ButtonBehavior::Toggle)
        .stylePreset(pl::modmenu::ButtonStylePreset::Accent)
        .onEvent([state](std::string_view, pl::modmenu::ButtonEvent event, float value) {
            if (event == pl::modmenu::ButtonEvent::StateChanged) *state = value > 0.5f;
        })
        .registerButton();
}

FreeCamModule::FreeCamModule() : Module("Free Cam", "Moves the render camera while keeping the player at the starting position.") {
    g_freecam = this;
}

FreeCamModule::~FreeCamModule() {
    if (m_overlayControls) {
        pl::modmenu::unregisterButton("bedrocktools.FreeCam.Forward");
        pl::modmenu::unregisterButton("bedrocktools.FreeCam.Back");
        pl::modmenu::unregisterButton("bedrocktools.FreeCam.Left");
        pl::modmenu::unregisterButton("bedrocktools.FreeCam.Right");
        pl::modmenu::unregisterButton("bedrocktools.FreeCam.Up");
        pl::modmenu::unregisterButton("bedrocktools.FreeCam.Down");
    }
    if (g_freecam == this) g_freecam = nullptr;
}

void FreeCamModule::onInit() {
    if (!m_renderHooked) {
        const auto addr = bedrocktools::memory::resolve(bedrocktools::memory::SignatureId::RenderLevel);
        if (addr) {
            auto handle = bedrocktools::hooks::install(reinterpret_cast<void*>(addr),
                                                       reinterpret_cast<void*>(freecamRenderHook),
                                                       reinterpret_cast<void**>(&g_renderLevelOriginal));
            m_renderHooked = handle != nullptr;
        }
    }
    updateControls();
}

void FreeCamModule::onEnable() {
    auto* client = bedrocktools::sdk::ClientInstance::current();
    if (!client) return;
    auto* player = client->localPlayer();
    if (!player) return;

    m_anchor = player->position();
    m_camera = m_anchor;
    resetControls();
}

void FreeCamModule::onDisable() {
    resetControls();
    auto* client = bedrocktools::sdk::ClientInstance::current();
    if (client) {
        auto* lrp = client->levelRenderer();
        if (lrp) lrp->cameraPosition() = m_anchor;
    }
}

void FreeCamModule::onFrame() {
    if (!enabled) return;
    auto* client = bedrocktools::sdk::ClientInstance::current();
    if (!client) return;
    auto* player = client->localPlayer();
    if (!player) return;

    // Hold the real player at the starting location. This intentionally does not
    // alter rotation, inventory, or network state.
    if (auto* state = player->stateVectorComponent()) {
        bedrocktools::sdk::field<bedrocktools::sdk::Vec3>(state, 0) = m_anchor;
    }

    auto rot = player->rotation();
    constexpr float deg = 3.14159265358979323846f / 180.0f;
    const float yaw = rot.y * deg;
    const float pitch = rot.x * deg;

    bedrocktools::sdk::Vec3 forward{
        -std::sin(yaw) * std::cos(pitch),
        -std::sin(pitch),
        std::cos(yaw) * std::cos(pitch)
    };
    bedrocktools::sdk::Vec3 right{
        std::cos(yaw), 0.0f, std::sin(yaw)
    };
    bedrocktools::sdk::Vec3 up{0.0f, 1.0f, 0.0f};

    bedrocktools::sdk::Vec3 delta{};
    if (m_forward) { delta.x += forward.x; delta.y += forward.y; delta.z += forward.z; }
    if (m_back)    { delta.x -= forward.x; delta.y -= forward.y; delta.z -= forward.z; }
    if (m_right)   { delta.x += right.x;   delta.z += right.z; }
    if (m_left)    { delta.x -= right.x;   delta.z -= right.z; }
    if (m_up)      delta.y += up.y;
    if (m_down)    delta.y -= up.y;

    const float len = std::sqrt(delta.x * delta.x + delta.y * delta.y + delta.z * delta.z);
    if (len > 0.001f) {
        const float scale = m_speed / len;
        m_camera.x += delta.x * scale;
        m_camera.y += delta.y * scale;
        m_camera.z += delta.z * scale;
    }

    const float dx = m_camera.x - m_anchor.x;
    const float dy = m_camera.y - m_anchor.y;
    const float dz = m_camera.z - m_anchor.z;
    const float distance = std::sqrt(dx * dx + dy * dy + dz * dz);
    if (distance > m_range && distance > 0.001f) {
        const float scale = m_range / distance;
        m_camera.x = m_anchor.x + dx * scale;
        m_camera.y = m_anchor.y + dy * scale;
        m_camera.z = m_anchor.z + dz * scale;
    }
}

bool FreeCamModule::onAttack(const bedrocktools::events::AttackEvent&) {
    return enabled;
}

void FreeCamModule::loadConfig(const nlohmann::json& j) {
    Module::loadConfig(j);
    if (j.contains("m_speed")) m_speed = std::clamp(j["m_speed"].get<float>(), 0.05f, 10.0f);
    if (j.contains("m_range")) m_range = std::clamp(j["m_range"].get<float>(), 8.0f, 512.0f);
    if (j.contains("m_overlayControls")) m_overlayControls = j["m_overlayControls"].get<bool>();
    updateControls();
}

void FreeCamModule::saveConfig(nlohmann::json& j) {
    Module::saveConfig(j);
    j["m_speed"] = m_speed;
    j["m_range"] = m_range;
    j["m_overlayControls"] = m_overlayControls;
}

void FreeCamModule::resetControls() {
    m_forward = m_back = m_left = m_right = m_up = m_down = false;
}

void FreeCamModule::updateControls() {
    const char* ids[] = {
        "bedrocktools.FreeCam.Forward", "bedrocktools.FreeCam.Back",
        "bedrocktools.FreeCam.Left", "bedrocktools.FreeCam.Right",
        "bedrocktools.FreeCam.Up", "bedrocktools.FreeCam.Down"
    };
    for (const char* id : ids) pl::modmenu::unregisterButton(id);
    if (!m_overlayControls) return;
    registerHoldButton(ids[0], "FreeCam Forward", &m_forward);
    registerHoldButton(ids[1], "FreeCam Back", &m_back);
    registerHoldButton(ids[2], "FreeCam Left", &m_left);
    registerHoldButton(ids[3], "FreeCam Right", &m_right);
    registerHoldButton(ids[4], "FreeCam Up", &m_up);
    registerHoldButton(ids[5], "FreeCam Down", &m_down);
}
