#pragma once

#include "../Module.hpp"
#include <bedrocktools/sdk/Types.hpp>
#include <string>

class FreeCamModule : public Module {
public:
    float m_speed = 0.6f;
    float m_range = 128.0f;
    bool m_overlayControls = true;

    FreeCamModule();
    ~FreeCamModule() override;

    void onInit() override;
    void onEnable() override;
    void onDisable() override;
    void onFrame() override;
    bool onAttack(const struct bedrocktools::events::AttackEvent& event) override;
    void loadConfig(const nlohmann::json& j) override;
    void saveConfig(nlohmann::json& j) override;

    void setMoveForward(bool v) { m_forward = v; }
    void setMoveBack(bool v) { m_back = v; }
    void setMoveLeft(bool v) { m_left = v; }
    void setMoveRight(bool v) { m_right = v; }
    void setMoveUp(bool v) { m_up = v; }
    void setMoveDown(bool v) { m_down = v; }

private:
    bedrocktools::sdk::Vec3 m_anchor{};
public:
    // Read by the render hook; kept public to avoid exposing a new SDK API.
    bedrocktools::sdk::Vec3 m_camera{};
private:
    bool m_forward = false;
    bool m_back = false;
    bool m_left = false;
    bool m_right = false;
    bool m_up = false;
    bool m_down = false;
    bool m_renderHooked = false;
    void updateControls();
    void resetControls();
};
